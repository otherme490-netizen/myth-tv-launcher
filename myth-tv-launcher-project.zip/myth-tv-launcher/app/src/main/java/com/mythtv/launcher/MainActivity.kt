package com.mythtv.launcher

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val pageColor = Color.rgb(9, 14, 29)
    private val accentColor = Color.rgb(94, 190, 255)
    private lateinit var appGrid: GridLayout
    private lateinit var clockView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pageColor
        window.navigationBarColor = pageColor
        createHomeScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::appGrid.isInitialized) {
            updateClock()
            loadInstalledApps()
        }
    }

    private fun createHomeScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(24), dp(42), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(19, 35, 65), pageColor, Color.rgb(30, 22, 55))
            )
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "MYTH"
            textSize = 28f
            letterSpacing = 0.16f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val suffix = TextView(this).apply {
            text = "  TV"
            textSize = 20f
            setTextColor(accentColor)
            typeface = Typeface.DEFAULT_BOLD
        }
        val spacer = View(this)
        clockView = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(210, 221, 240))
        }
        header.addView(title)
        header.addView(suffix)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(clockView)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(46)))

        val headline = TextView(this).apply {
            text = "Entertainment,\nmade yours."
            textSize = 32f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(7))
        }
        root.addView(headline)
        val description = TextView(this).apply {
            text = "Your apps, all in one place"
            textSize = 15f
            setTextColor(Color.rgb(166, 184, 211))
            setPadding(0, 0, 0, dp(19))
        }
        root.addView(description)
        val section = TextView(this).apply {
            text = "YOUR APPS"
            textSize = 13f
            letterSpacing = 0.15f
            setTextColor(accentColor)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(section)
        appGrid = GridLayout(this).apply {
            columnCount = 5
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        root.addView(appGrid, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply {
            text = "Navigate with the directional pad  •  Press OK to open an app"
            textSize = 12f
            setTextColor(Color.rgb(135, 153, 181))
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, dp(28)))
        setContentView(root)
        updateClock()
        loadInstalledApps()
    }

    private fun updateClock() {
        clockView.text = SimpleDateFormat("EEE, dd MMM   •   h:mm a", Locale.getDefault()).format(Date())
    }

    @Suppress("DEPRECATION")
    private fun loadInstalledApps() {
        appGrid.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }

        for (app in apps) {
            val launchIntent = pm.getLaunchIntentForPackage(app.packageName) ?: continue
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = makeTileBackground(Color.rgb(31, 45, 72))
                setPadding(dp(7), dp(12), dp(7), dp(10))
                setOnFocusChangeListener { view, focused ->
                    view.background = makeTileBackground(
                        if (focused) Color.rgb(48, 79, 119) else Color.rgb(31, 45, 72),
                        if (focused) accentColor else Color.TRANSPARENT
                    )
                    view.animate().scaleX(if (focused) 1.05f else 1f)
                        .scaleY(if (focused) 1.05f else 1f).setDuration(130).start()
                }
                setOnClickListener { startActivity(launchIntent) }
            }
            val iconView = ImageView(this).apply {
                setImageDrawable(pm.getApplicationIcon(app))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            tile.addView(iconView, LinearLayout.LayoutParams(dp(52), dp(52)))
            val nameView = TextView(this).apply {
                text = pm.getApplicationLabel(app).toString()
                textSize = 12f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(0, dp(8), 0, 0)
            }
            tile.addView(nameView, LinearLayout.LayoutParams(-1, dp(40)))
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(112)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(6), dp(6), dp(6), dp(6))
            }
            appGrid.addView(tile, params)
        }
        if (apps.isEmpty()) {
            appGrid.addView(TextView(this).apply {
                text = "No launchable apps found."
                textSize = 17f
                setTextColor(Color.WHITE)
            })
        } else {
            appGrid.getChildAt(0)?.requestFocus()
        }
    }

    private fun makeTileBackground(fillColor: Int, strokeColor: Int = Color.TRANSPARENT) =
        GradientDrawable().apply {
            setColor(fillColor)
            cornerRadius = dp(17).toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(2), strokeColor)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
