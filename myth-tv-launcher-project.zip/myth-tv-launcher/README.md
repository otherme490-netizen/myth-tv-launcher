# Myth TV Launcher

A lightweight Android TV launcher prototype written in Kotlin.

- Designed for Android TV remote navigation.
- Lists installed apps that expose a launch intent.
- Initial prototype; test on the target Acer TV before setting it as the default launcher.

The GitHub Actions workflow builds a debug APK using JDK 17 and Gradle 8.9.
