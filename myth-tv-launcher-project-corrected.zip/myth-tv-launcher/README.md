# MYTH TV Launcher

A basic Android TV launcher prototype.

## Build
Run `gradle assembleDebug` from this project folder with JDK 17 and Android SDK platform 35 installed.

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
