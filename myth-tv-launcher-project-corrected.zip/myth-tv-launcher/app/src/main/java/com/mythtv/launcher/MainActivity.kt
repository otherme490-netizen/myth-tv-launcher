package com.mythtv.launcher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val navy = Color.rgb(10, 18, 38)
    private val accent = Color.rgb(70, 150, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 24)
            setBackgroundColor(navy)
        }

        val header = TextView(this).apply {
            text = "MYTH TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "Your entertainment, one place"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 24)
        }
        root.addView(subtitle)

        val grid = GridLayout(this).apply {
            columnCount = 5
            useDefaultMargins = true
        }

        val launchable = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0
        ).ifEmpty {
            packageManager.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            )
        }.sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        launchable.forEach { info ->
            val appName = info.loadLabel(packageManager).toString()
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(10, 14, 10, 14)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(24, 36, 62))
                    cornerRadius = 18f
                }
                isFocusable = true
                isFocusableInTouchMode = true
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = GradientDrawable().apply {
                        setColor(if (hasFocus) Color.rgb(40, 65, 105) else Color.rgb(24, 36, 62))
                        cornerRadius = 18f
                        if (hasFocus) setStroke(3, accent)
                    }
                }
                setOnClickListener {
                    packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)?.let {
                        startActivity(it)
                    }
                }
            }

            val icon = TextView(this).apply {
                text = "●"
                textSize = 28f
                setTextColor(accent)
                gravity = Gravity.CENTER
            }
            tile.addView(icon)

            val label = TextView(this).apply {
                text = appName
                textSize = 13f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(0, 8, 0, 0)
            }
            tile.addView(label)

            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            grid.addView(tile, params)
        }

        root.addView(grid, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }
}
